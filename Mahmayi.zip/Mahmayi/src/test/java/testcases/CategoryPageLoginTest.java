package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBase;
import pages.CategoryPageLogin;
import pages.LoginPage;
import pages.LogoutPage;

public class CategoryPageLoginTest extends TestBase {

	static CategoryPageLogin categorypageLogin;
	static LoginPage loginpage;

	public CategoryPageLoginTest() {
		super();
	}

	@BeforeClass
	public  void setup() throws Exception {
		TestBase.initialization(); // calling initilization method
		loginpage = new LoginPage(driver);
		LoginPage.login(property.getProperty("email"), property.getProperty("password"));
		Thread.sleep(5000);
	}

	@SuppressWarnings("static-access")
	@Test(enabled = true)
	public static void LoggedInUserTest() {
		categorypageLogin.Loggedinuser();
	}



	@AfterClass
	public static void teardown() {
		LogoutPage.logout();
	}
}
