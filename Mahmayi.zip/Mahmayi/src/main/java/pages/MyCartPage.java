package pages;

import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.aventstack.extentreports.Status;

import base.TestBase;

public class MyCartPage extends TestBase {

	static MyCartPage mycartPage = new MyCartPage();
	static List<WebElement> cartList, minicartList;
	static String productname, output;
	static int cartlistsize, minicartlistsize;
	static WebElement lastproduct2;

	public MyCartPage() {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[1]/div/div[2]/strong/a")
	static WebElement product;

	@FindBy(xpath = "//*[contains(text(),'Add to Cart')]")
	static WebElement AddToCart;

	@FindBy(xpath = "/html/body/div[3]/header/div[2]/div[1]/a")
	/*
	 * //*[contains(text(),'My Cart')]
	 */ static WebElement openCart;

	@FindBy(xpath = "//*[@id='maincontent']/div[1]/div[2]/div/div/div")
	static WebElement msg;

	@FindBy(xpath = "//*[@id='minicart-content-wrapper']/div[2]/div[5]/div/a/span")
	static WebElement view_edit_cart;

	@FindBy(xpath = "//*[@id='shopping-cart-table']/tbody")
	static WebElement listincart;

	@FindBy(xpath = "//*[@id='shopping-cart-table']")
	static WebElement table;

	@FindBy(xpath = "//*[@id='shopping-cart-table']/tbody/tr[2]/td/div/a[3]")
	static WebElement delete;

	@FindBy(xpath = "//*[@class='minicart-items-wrapper']/ol")
	static WebElement listinminicart;

	public static String pdp() {
		driver.get(property.getProperty("url") + "office-furniture.html");
		HomePage.implicitwait();
		productname = HomePage.getInnerHTML(product);
		return productname;
	}

	public static void clickAddToCartBtn() {
		HomePage.implicitwait();
		HomePage.ElementClickIntercepted(AddToCart);
		System.out.println("clicked on Add to cart ");
		testlogger().log(Status.INFO, "clicked on Add to cart ");
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void getmessage() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(document.body.scrollHeight, 0)");
		try {
			HomePage.NoSuchElement(msg);
			String successmsg = msg.getText();

			if (successmsg.contains("added")) {
				System.out.println(successmsg);
				testlogger().log(Status.INFO, successmsg);
			} else if (successmsg.equalsIgnoreCase("We can't add this item to your shopping cart right now.")) {
				System.out.println(successmsg);
				testlogger().log(Status.INFO, successmsg);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static void clickToOpenCart() {
		HomePage.ElementClickIntercepted(openCart);
		openCart.click();
		System.out.println("clicked on cart ");
		testlogger().log(Status.INFO, "clicked on cart ");
	}

	public static void ClickViewAndEditCart() {
		HomePage.ElementClickIntercepted(view_edit_cart);
		System.out.println("clicked on view and edit cart ");
		testlogger().log(Status.INFO, "clicked on view and edit cart ");
	}

	public static void OpenCart() {
		driver.get(property.getProperty("url") + "checkout/cart/");
		HomePage.implicitwait();
	}

	public static int ListInCart() {
		HomePage.implicitwait();
		cartList = listincart.findElements(By.tagName("tr"));
		cartlistsize = cartList.size();
		testlogger().log(Status.INFO, "Products in cart:" + cartlistsize);
		System.out.println("Products in cart:" + cartlistsize);
		return cartlistsize;
	}

	public static void checkCart() {
		String output;

		lastproduct2 = driver
				.findElement(By.xpath("//*[@id='shopping-cart-table']/tbody[last()]/tr/td[1]/div/strong/a"));
		output = lastproduct2.getAttribute("innerHTML").trim();
		System.out.println(output);
		testlogger().log(Status.INFO, output);

		if (output.equals(productname)) {
			System.out.println("Product added to Cart");
			testlogger().log(Status.INFO, "Product added to Cart");
		} else {
			System.out.println("Product not added to CArt");
			testlogger().log(Status.INFO, "Product not added to Cart");
		}

	}

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div/div[2]/p[1]")
	static WebElement noitemincart;

	@SuppressWarnings("static-access")
	public static void deleteitem() {
		try {
			noitemincart.isDisplayed();
			System.out.println("You have no items in your shopping cart.");
			testlogger().log(Status.INFO, "You have no items in your shopping cart.");
		} catch (Exception e) {
			// TODO: handle exception
		}

		try {
			WebElement product2 = driver
					.findElement(By.xpath("//*[@id='shopping-cart-table']/tbody/tr[1]/td[1]/div/strong/a"));
			output = product2.getAttribute("innerHTML").trim();
			System.out.println("Product Name" + "-" + output);
			testlogger().log(Status.INFO, "Product Name" + "-" + output);

			int before = MyCartPage.ListInCart();

			HomePage.ElementClickIntercepted(delete);
			System.out.println("Clicked on  deleted.");
			testlogger().log(Status.INFO, "Clicked on deleted.");

			driver.navigate().refresh();
			HomePage.implicitwait();
			int after = mycartPage.ListInCart();
			int r = before - after;
			if (r == 1) {
				System.out.println("Product  deleted.");
				testlogger().log(Status.INFO, "Product deleted.");
			} else {
				System.out.println("Product not  deleted.");
				testlogger().log(Status.INFO, "Product not deleted.");
			}

		} catch (Exception e) {

		}

	}

	public static void deletecheckMiniCart() {
		String outputt;

		for (int i = 1; i <= minicartlistsize; i++) {

			WebElement product2 = driver.findElement(By.xpath("//*[@id='mini-cart']/li[" + i + "]/div/div/strong/a"));
			outputt = product2.getAttribute("innerHTML").trim();
			System.out.println(i + "-" + outputt);
			testlogger().log(Status.INFO, i + "-" + outputt);

			if (outputt.equals(output)) {
				System.out.println("Product not deleted from  MiniCart");
				testlogger().log(Status.INFO, "Product deleted from  MiniCart");
			} else {
				System.out.println("Product not deleted from  MiniCart");
				testlogger().log(Status.INFO, "Product deleted from  MiniCart");
			}

		}
	}

	public static void cartSubtotal() {
		float p, q, multiply;

		HomePage.NoSuchElement(table);

		List<WebElement> products = table.findElements(By.tagName("tbody"));
		testlogger().log(Status.INFO, "Products in shopping cart:" + products.size());
		System.out.println("Products in shopping cart:" + products.size());

		for (int i = 1; i <= products.size(); i++) {

			WebElement price = driver.findElement(
					By.xpath("//*[@id='shopping-cart-table']/tbody[" + i + "]/tr[1]/td[2]/span/span/span"));
			String priceoutput = price.getAttribute("innerHTML").trim();

			String priceoutput1 = priceoutput.replaceAll("[^0-9.]", "");
			p = Float.parseFloat(priceoutput1);
			System.out.println("Price of item " + i + "-" + priceoutput1);
			testlogger().log(Status.INFO, "Price of item " + i + "-" + priceoutput1);

			WebElement qty = driver.findElement(
					By.xpath("//*[@id='shopping-cart-table']/tbody[" + i + "]/tr[1]/td[3]/div/div/label/input"));
			String qtyoutput = qty.getAttribute("value").trim();
			q = Float.parseFloat(qtyoutput);
			System.out.println("Quantity of item " + i + "-" + qtyoutput);
			testlogger().log(Status.INFO, "Quantity of item " + i + "-" + qtyoutput);

			WebElement subtotal = driver.findElement(
					By.xpath("//*[@id='shopping-cart-table']/tbody[" + i + "]/tr[1]/td[4]/span/span/span"));
			String subTotal = subtotal.getAttribute("innerHTML").trim();
			String expected = subTotal.replaceAll("[^0-9.]", "");
			System.out.println("expected:" + expected);
			testlogger().log(Status.INFO, "expected:" + expected);

			multiply = p * q;
			String actual = Float.toString(multiply);
			System.out.println("Actual:" + actual);
			testlogger().log(Status.INFO, "Actual:" + actual);
			if (actual.equals(expected)) {
				System.out.println("subtotal is equal to  Price x Qty.");
				testlogger().log(Status.PASS, "Subtotal is equal to  Price x Qty.");
			}

		}
	}

	@FindBy(xpath = "//*[@id='cart-totals']/div/table/tbody/tr[4]/td/strong/span")
	static WebElement OrderTotal;

	@FindBy(xpath = "//*[@id='cart-totals']/div/table/tbody/tr[1]/td/span")
	static WebElement SubTotal;

	@FindBy(xpath = "//*[@id='cart-totals']/div/table/tbody/tr[3]/td/span")
	static WebElement Shipping;

	@FindBy(xpath = "//*[@id='cart-totals']/div/table/tbody/tr[2]/td/span/span")
	static WebElement Discount;

	public static void cartOrderTotal() {

		HomePage.ElementClickIntercepted(OrderTotal);
		String expected = OrderTotal.getAttribute("innerHTML").replaceAll("[^0-9.]", "");

		testlogger().log(Status.INFO, "Order Total: " + expected);
		System.out.println("Order Total: " + expected);
		HomePage.ElementClickIntercepted(SubTotal);

		float subtotal = Float.parseFloat(SubTotal.getAttribute("innerHTML").replaceAll("[^0-9.]", ""));

		testlogger().log(Status.INFO, "Sub Total: " + subtotal);
		System.out.println("Sub Total: " + subtotal);
		HomePage.ElementClickIntercepted(Shipping);

		float shipping = Float.parseFloat(Shipping.getAttribute("innerHTML").replaceAll("[^0-9.]", ""));

		testlogger().log(Status.INFO, "Shipping: " + shipping);
		System.out.println("Shipping: " + shipping);

		HomePage.ElementClickIntercepted(Discount);

		float discount = Float.parseFloat(Discount.getAttribute("innerHTML").replaceAll("[^0-9.]", ""));

		testlogger().log(Status.INFO, "Discount: " + discount);
		System.out.println("Discount: " + discount);

		float ordertotal = (subtotal + shipping) - discount;
		String actual = Float.toString(ordertotal);
		testlogger().log(Status.INFO, "Actual: " + actual);
		System.out.println("Actual: " + actual);

		if (actual.equalsIgnoreCase(expected)) {
			System.out.println("ordertotal is equal to Subtotal + shipping - discount.");
			testlogger().log(Status.PASS, "ordertotal is equal to  Subtotal + shipping - discount.");
		} else {
			System.out.println("ordertotal is not equal to Subtotal + shipping - discount.");
			testlogger().log(Status.SKIP, "ordertotal is not equal to  Subtotal + shipping - discount.");
		}
	}

	public static void cartItemsCount() {
		float subtotal1n;

		HomePage.ElementClickIntercepted(SubTotal);

		float subtotal1 = Float.parseFloat(SubTotal.getAttribute("innerHTML").replaceAll("[^0-9.]", ""));

		testlogger().log(Status.INFO, "Sub Total: " + subtotal1);
		System.out.println("Sub Total: " + subtotal1);

		List<WebElement> products = table.findElements(By.tagName("tbody"));
		testlogger().log(Status.INFO, "Products in shopping cart:" + products.size());
		System.out.println("Products in shopping cart:" + products.size());

		ArrayList<Integer> CartPriceList = new ArrayList<Integer>();

		for (int i = 1; i <= products.size(); i++) {

			WebElement product2 = driver
					.findElement(By.xpath("//*[@id='shopping-cart-table']/tbody[" + i + "]/tr[1]/td[1]/div/strong/a"));
			String output = product2.getAttribute("innerHTML").trim();
			System.out.println(i + "-" + output);
			testlogger().log(Status.INFO, i + "-" + output);

			WebElement SubTotaln = driver.findElement(
					By.xpath("//*[@id='shopping-cart-table']/tbody[" + i + "]/tr[1]/td[4]/span/span/span"));
			subtotal1n = Float.parseFloat(SubTotaln.getAttribute("innerHTML").replaceAll("[^0-9.]", ""));

			testlogger().log(Status.INFO, "Sub Total: " + subtotal1n);
			System.out.println("Sub Total: " + subtotal1n);

			CartPriceList.add((int) subtotal1n);

		}
		System.out.println(CartPriceList);

		float sum = 0;
		for (float i : CartPriceList) {
			sum += i;
		}
		System.out.println(sum);
		String str1 = Float.toString(sum);
		testlogger().log(Status.INFO, "Sum of price of all items in list: " + str1);

		if (subtotal1 == sum) {
			System.out.println("Subtotal = Subtotl of item 1 + Subtotl of item 2 + ... +Subtotl of item n");
			testlogger().log(Status.PASS, "Subtotal = Subtotl of item 1 + Subtotl of item 2 + ... +Subtotl of item n");
		} else {
			System.out.println("Subtotal != Subtotl of item 1 + Subtotl of item 2 + ... +Subtotl of item n");
			testlogger().log(Status.SKIP, "Subtotal != Subtotl of item 1 + Subtotl of item 2 + ... +Subtotl of item n");
		}
	}

	@FindBy(xpath = "/html/body/div[3]/header/div[2]/div[1]/a/span[2]/span[1]")
	static WebElement cartCounterNo;

	public static int getCounterNo() {
		HomePage.ElementClickIntercepted(cartCounterNo);

		int before = Integer.parseInt(cartCounterNo.getText());
		testlogger().log(Status.INFO, "Counter No:" + cartCounterNo.getText());
		System.out.println("Counter No:" + before);

		return before;
	}

	@FindBy(xpath = "//*[@id='mini-cart']/li[1]/div/div/div[1]/div[2]/input")
	static WebElement firstproductinput;

	@FindBy(xpath = "//*[@id='mini-cart']/li[1]/div/div/div[1]/div[2]/button")
	static WebElement update;

	public static void setAttribute(WebElement element, String attName, int i) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", element, attName, i);
	}

	public static void QTY(String qty) {

		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].setAttribute('data-item-qty', arguments[1])",
				driver.findElement(By.xpath("//*[@id='mini-cart']/li[1]/div/div/div[1]/div[2]/input")), qty);

		HomePage.ElementClickIntercepted(firstproductinput);
		firstproductinput.click();
		firstproductinput.sendKeys(Keys.CONTROL + "a");
		firstproductinput.sendKeys(Keys.DELETE);
		firstproductinput.sendKeys(qty + Keys.TAB + Keys.ENTER);

		System.out.println("Quantity increased: " + qty);
		testlogger().log(Status.INFO, "Quantity increased: " + qty);

		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@FindBy(xpath = "//*[@id='shopping-cart-table']/tbody[last()]/tr/td[3]/div/div/label/input")
	static WebElement lastproduct;

	public static void CounterNo() throws InterruptedException {
		int before = getCounterNo();

		clickToOpenCart();

		QTY("3");

		int after = getCounterNo();

		if (before < after) {
			System.out.println("Cart updated");
			testlogger().log(Status.INFO, "Cart updated");
		} else {
			System.out.println("Cart not updated");
			testlogger().log(Status.INFO, "Cart not updated");
		}

		OpenCart();

		HomePage.ElementClickIntercepted(lastproduct);
		String qt = lastproduct.getAttribute("value");
		System.out.println("Quantity:" + qt);
		if (qt.matches("3")) {
			System.out.println("Quantity updated in minicart is updated in Cart also.");
		} else {

		}
	}

	public static int ListInMiniCart() {
		HomePage.implicitwait();
		HomePage.NoSuchElement(listinminicart);
		minicartList = listinminicart.findElements(By.tagName("li"));
		minicartlistsize = minicartList.size();
		testlogger().log(Status.INFO, "Products in minicart:" + minicartlistsize);
		System.out.println("Products in minicart:" + minicartlistsize);
		return minicartlistsize;
	}

	public static void checkMiniCart() {
		String output;

		for (int i = 1; i <= minicartlistsize; i++) {

			WebElement product2 = driver.findElement(By.xpath("//*[@id='mini-cart']/li[" + i + "]/div/div/strong/a"));
			output = product2.getAttribute("innerHTML").trim();
			System.out.println(i + "-" + output);
			testlogger().log(Status.INFO, i + "-" + output);

			if (output.equals(productname)) {
				System.out.println("Product added to Cart");
				testlogger().log(Status.INFO, "Product added to Cart");
			} else {
				System.out.println("Product not added to CArt");
				testlogger().log(Status.INFO, "Product not added to Cart");
			}

		}
	}

	public static void name() {
		WebElement stock;

		HomePage.NoSuchElement(table);

		List<WebElement> products = table.findElements(By.tagName("tbody"));
		testlogger().log(Status.INFO, "Products in shopping cart:" + products.size());
		System.out.println("Products in shopping cart:" + products.size());

		for (int i = 1; i <= products.size(); i++) {

			try {
				stock = driver.findElement(
						By.xpath("//*[@id='shopping-cart-table']/tbody[" + i + "]/tr[1]/td[1]/div/div/div"));
				String stockmsg = stock.getAttribute("innerHTML").trim();
				System.out.println(i + " - " + stockmsg);
				testlogger().log(Status.INFO, i + " - " + stockmsg);

				if (stock.isDisplayed()) {
					WebElement Name = driver.findElement(
							By.xpath("//*[@id='shopping-cart-table']/tbody[" + i + "]/tr[1]/td[1]/div/strong/a"));
					String productName = Name.getAttribute("innerHTML").trim();
					System.out.println("Product Name " + productName);
					testlogger().log(Status.INFO, productName);
				}

			} catch (Exception e) {
				// TODO: handle exception
			}

		}
	}

	public static void totalSum() {
		clickToOpenCart();
		String priceoutput, qtyoutput;
		ArrayList<Double> additemprice = new ArrayList<Double>();
		ArrayList<Double> additem = new ArrayList<Double>();

		WebElement itemtotal = driver
				.findElement(By.xpath("//*[@id='minicart-content-wrapper']/div[2]/div[1]/span[1]"));
		String expectedi = itemtotal.getAttribute("innerHTML").trim();
		double expecteditems = Double.parseDouble(expectedi);
		System.out.println("expecteditems:" + expecteditems);
		testlogger().log(Status.INFO, "expecteditems:" + expecteditems);

		WebElement subtotal = driver
				.findElement(By.xpath("//*[@id='minicart-content-wrapper']/div[2]/div[2]/div/span/span"));
		String expectedP = subtotal.getAttribute("innerHTML").replaceAll("[^0-9.]", "").trim();
		double expectedPrice = Double.parseDouble(expectedP);
		System.out.println("expectedPrice:" + expectedPrice);
		testlogger().log(Status.INFO, "expectedPrice:" + expectedPrice);

		minicartList = listinminicart.findElements(By.tagName("li"));
		minicartlistsize = minicartList.size();
		testlogger().log(Status.INFO, "Products in minicart:" + minicartlistsize);
		System.out.println("Products in minicart:" + minicartlistsize);

		for (int i = 1; i <= minicartlistsize; i++) {

			WebElement price = driver.findElement(
					By.xpath("//*[@id='mini-cart']/li[" + i + "]/div/div/div[1]/div[1]/span/span/span/span"));
			priceoutput = price.getAttribute("innerHTML").replaceAll("[^0-9.]", "").trim();
			double p = Double.parseDouble(priceoutput);

			WebElement qty = driver
					.findElement(By.xpath("//*[@id='mini-cart']/li[" + i + "]/div/div/div[1]/div[2]/input"));
			qtyoutput = qty.getAttribute("data-item-qty").trim();
			double q = Double.parseDouble(qtyoutput);
			System.out.println(i + "- Price : " + p + " Qty :" + q);
			testlogger().log(Status.INFO, i + "- Price : " + p + " Qty :" + q);

			double multiply = (p * q);
			String actual = Double.toString(multiply);
			// String rounfoff=decimalformat.format(actual);
			System.out.println("Actual:" + actual);
			testlogger().log(Status.INFO, "Actual:" + actual);

			additemprice.add(multiply);
			additem.add(q);
		}

		
		System.out.println(additemprice + "\n" + additem);

		double sum = 0;
		for (double i : additemprice) {
			sum += i;
		}
		System.out.println(sum);
		
		if (sum==expectedPrice) {
			System.out.println("subtotal is equal to  Price x Qty.");
			testlogger().log(Status.PASS, "Subtotal is equal to  Price x Qty.");
		} else {
			System.out.println("ERROR in Price Subtotal !!!");
			testlogger().log(Status.PASS,"ERROR in Price Subtotal !!!");
		}

		double count = 0;
		for (double i : additem) {
			count += i;
		}
		System.out.println(count);
		if (count==expecteditems) {
			System.out.println("itemtotal is equal to  item_1 qty + item_n qty");
			testlogger().log(Status.PASS, "itemtotal is equal to  item_1 qty + item_n qty");
		} else {
			System.out.println("ERROR in items total !!!");
			testlogger().log(Status.PASS,"ERROR in items total !!!");
		}
	}
}
