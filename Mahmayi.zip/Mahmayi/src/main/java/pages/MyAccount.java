package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import base.TestBase;

public class MyAccount extends TestBase {
	static MyAccount myAccount = new MyAccount();

	static JavascriptExecutor executor = (JavascriptExecutor) driver;

	@FindBy(xpath = "//*[@id='maincontent']/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/p")
	static WebElement nm;

	@FindBy(xpath = "//*[@id='maincontent']/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/a[1]/span")
	static WebElement edit;

	@FindBy(xpath = "//*[@id='maincontent']/div[2]/div[1]/div[3]/div[2]/div/div[2]/a[2]")
	static WebElement changepassword;

	@FindBy(id = "email")
	static WebElement Password;

	@FindBy(id = "current-password")
	static WebElement currentPassword;

	@FindBy(id = "password")
	static WebElement newPassword;

	@FindBy(id = "password-confirmation")
	static WebElement confirmnewPassword;

	static WebDriverWait wait;

	public static void getUsername() {
		driver.get(property.getProperty("myaccountpage"));
		System.out.println("Navigated to My Account page.");

		String name = driver.findElement(By.xpath("//*[@id='maincontent']/div[2]/div[1]/div[3]/div[2]/div[1]/div[1]/p"))
				.getAttribute("innerHTML").trim().replace("<br>", "");
		System.out.println(name);
		testlogger().log(Status.INFO, name);
	}

	public static void editName() {

		driver.findElement(By.xpath("//*[@id='maincontent']/div[2]/div[1]/div[3]/div[2]/div[1]/div[2]/a[1]/span"))
				.click();
		System.out.println("clicked on edit");
		testlogger().log(Status.INFO, "clicked on edit ");

	}

	public static void ChangeName() {
		WebElement FirstName = driver.findElement(By.id("firstname"));

		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(FirstName));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", FirstName);

		((WebElement) FirstName).clear();
		FirstName.sendKeys(property.getProperty("FirstName"));

		WebElement LastName = driver.findElement(By.id("lastname"));

		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(LastName));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", LastName);

		((WebElement) LastName).clear();
		LastName.sendKeys(property.getProperty("LastName"));

		System.out.println("entered data: " + "First Name - " + property.getProperty("FirstName") + "Last Name - "
				+ property.getProperty("LastName"));
		testlogger().log(Status.INFO, "entered data: " + "First Name - " + property.getProperty("FirstName")
				+ "Last Name - " + property.getProperty("LastName"));
	}

	public static void ClickonSave() {
		WebElement save = driver.findElement(By.xpath("//*[@id='form-validate']/div[2]/div[1]/button"));

		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(save));

		save.click();
		System.out.println("clicked on save button");
		testlogger().log(Status.INFO, "clicked on save button");
	}

	public static void ChangeEmail() {

		WebElement changeemail = driver.findElement(By.id("change-email"));

		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(changeemail));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", changeemail);

		System.out.println("clicked on Change Email checkbox");
		testlogger().log(Status.INFO, "clicked on Change Email checkbox");

		WebElement Email = driver.findElement(By.id("email"));
		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(Email));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", Email);

		Email.clear();
		Email.sendKeys(property.getProperty("changeEmail"));

		WebElement currentpass = driver.findElement(By.id("current-password"));
		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(currentpass));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", currentpass);

		currentpass.clear();
		currentpass.sendKeys(property.getProperty("password"));

		System.out.println("entered data: " + "Email - " + property.getProperty("changeEmail") + " current password - "
				+ property.getProperty("password"));
		testlogger().log(Status.INFO, "entered data: " + "Email - " + property.getProperty("changeEmail")
				+ " current password - " + property.getProperty("password"));
	}

	public static void ClickchangePassword() {
		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(changepassword));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", changepassword);

	}

	public static void ChangePassword() {

		WebElement changepass = driver.findElement(By.id("change-password"));

		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(changepass));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", changepass);

		System.out.println("clicked on Change Password checkbox");
		testlogger().log(Status.INFO, "clicked on Change Password checkbox");

		WebElement currentpassword = driver.findElement(By.id("current-password"));

		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(changepass));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", currentpassword);
		currentpassword.sendKeys(property.getProperty("password"));

		WebElement newpassword = driver.findElement(By.id("password"));
		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(newpassword));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", newpassword);
		newpassword.sendKeys(property.getProperty("password"));

		WebElement confirmpassword = driver.findElement(By.id("password-confirmation"));
		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(confirmpassword));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", confirmpassword);
		confirmpassword.sendKeys(property.getProperty("password"));

		System.out.println(
				"entered data: " + "Current password - " + property.getProperty("password") + " New password - "
						+ property.getProperty("password") + " Confirm password - " + property.getProperty("password"));
		testlogger().log(Status.INFO,
				"entered data: " + "Current password - " + property.getProperty("password") + " current password - "
						+ property.getProperty("password") + " Confirm password - " + property.getProperty("password"));
	}

	public static void getSuccessmsgtext() {
		HomePage.implicitwait();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebElement Successmsg = driver.findElement(By.xpath("//*[@id='maincontent']/div[1]/div[2]/div/div/div"));
		new WebDriverWait(driver, 60).ignoring(NoSuchElementException.class)
				.until(ExpectedConditions.elementToBeClickable(Successmsg));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Successmsg);

		String text = Successmsg.getText();
		System.out.println(text);
		testlogger().log(Status.INFO, text);
	}

}
