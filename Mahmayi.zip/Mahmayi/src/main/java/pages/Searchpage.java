package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;

import com.aventstack.extentreports.Status;

import base.TestBase;

public class Searchpage extends TestBase {
	static Searchpage searchpage = new Searchpage();

	public Searchpage() {

		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "search")
	static WebElement Searchbox;

	@FindBy(xpath = "//*[@id='search_mini_form']/div[1]/div/div[1]/div[3]/div[1]/div[1]/div[1]/ul")
	static WebElement suggestion;

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[2]/div[3]/ol")
	static WebElement suggestion2;

	public static void openhomepage() {
		driver.get(property.getProperty("url"));
		HomePage.implicitwait();

	}

	public static void clickonSerachbox() {
		HomePage.ElementClickIntercepted(Searchbox);
		System.out.println("clicked on Searchbox ");
		testlogger().log(Status.INFO, "clicked on Searchbox ");
	}

	public static void search() {
		Searchbox.sendKeys(property.getProperty("search"));

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<WebElement> rows = suggestion.findElements(By.tagName("li"));
		testlogger().log(Status.INFO, "Total suggestions:" + rows.size());
		System.out.println("Total suggestions:" + rows.size());

		for (WebElement elem : rows) {
			testlogger().log(Status.INFO, elem.getText());
			System.out.println(elem.getText());
			try {
				System.out.println(driver.findElement(By.xpath("//*[@id='search_mini_form']/div[1]/div/div[1]/div[3]/div[2]/span"))
						.getText());
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

		Searchbox.sendKeys(Keys.ENTER);
		List<WebElement> rows2 = suggestion2.findElements(By.tagName("li"));
		testlogger().log(Status.INFO, "Total suggestions:" + rows2.size());
		System.out.println("Total suggestions:" + rows2.size());

		for (int i = 1; i <= rows2.size(); i++) {
			WebElement list = driver.findElement(By
					.xpath("//*[@id='maincontent']/div[3]/div[1]/div[2]/div[3]/ol/li[" + i + "]/div/div[2]/strong/a"));

			testlogger().log(Status.INFO, i + " - " + list.getText());
			System.out.println(i + " - " + list.getText());
			if (list.getText().equalsIgnoreCase(property.getProperty("search"))) {
			}
		}

	}
}
