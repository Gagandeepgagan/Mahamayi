package pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import base.TestBase;

/*with  login*/
public class CategoryPageLogin extends TestBase {

	static CategoryPageLogin categorypageLogin = new CategoryPageLogin();
	static String parent, output, href, str;
	static WebElement ProductName, ProductPrice, product, menulink, linkhref, AddtoCart, Preorder;

	public CategoryPageLogin() {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='store.menu']/section[1]/nav/ul")
	static WebElement Mlist;

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[4]/ol")
	static WebElement grid;
	@FindBy(xpath = "//*[contains(text(),'Add to Cart')]")
	static WebElement AddToCart;

	public static void Loggedinuser() {

		HomePage.implicitwait();
		String[] exp = { "Wholesale Office Furniture UAE | Office Furniture Outlet Dubai",
				"Buy Affordable Office Chairs Online in Dubai|Small Office Chair UAE",
				"Buy Electronic Safe for Sale in Abu Dhabi,Dubai,UAE | Mahmayi", "Gaming & Home", "Interiors",
				"Shop by Series | Mahmayi Office Furniture", "Sale of Office Furniture | Mahmayi Office Furniture",
				"Top Rated – Curated Collection | Mahmayi" };
		parent = driver.getWindowHandle();
		testlogger().log(Status.INFO, "Parent window title:" + driver.getTitle());
		System.out.println("Parent window title:" + driver.getTitle());
		HomePage.implicitwait();

		List<WebElement> menus = Mlist.findElements(By.tagName("li"));
		testlogger().log(Status.INFO, "Total menus:" + menus.size());
		System.out.println("Total menus:" + menus.size());

		for (int i = 1; i <= 1; i++) {

			try {
				product = driver.findElement(By.xpath("//div[@class='container']/nav/ul/li[" + i + "]/a/span[2]"));
				output = product.getAttribute("innerHTML");
				testlogger().log(Status.INFO, i + "-" + output);
				System.out.println(i + "-" + output);
			} catch (Exception e) {
				// TODO: handle exception
			}

			menulink = driver.findElement(By.xpath("//*[@id='store.menu']/section[2]/nav/ul/li[" + i + "]/a"));
			href = menulink.getAttribute("href");
			testlogger().log(Status.INFO, href);
			System.out.println(href);
			driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
			driver.get(href);

			/*
			 * str = Keys.chord(Keys.CONTROL, Keys.ENTER);
			 * 
			 * linkhref = driver.findElement(By.xpath("//a[@href='" + href + "']"));
			 * 
			 * HomePage.jsclick(linkhref);
			 * 
			 * linkhref.sendKeys(str);
			 */

			/*
			 * Set<String> set = driver.getWindowHandles(); testlogger().log(Status.INFO,
			 * "total windows :" + set.size()); System.out.println("total windows :" +
			 * set.size()); Iterator<String> iterate = set.iterator(); while
			 * (iterate.hasNext()) { String child_window = iterate.next();
			 * 
			 * if (!parent.equals(child_window)) { WebDriver child =
			 * driver.switchTo().window(child_window); testlogger().log(Status.INFO,
			 * "Switched to child window.");
			 */
			System.out.println("Switched to child window.");
			String childWinTitle = driver.getTitle();
			testlogger().log(Status.INFO, "Child window Title:" + childWinTitle);
			System.out.println("Child window Title:" + childWinTitle);
			Assert.assertEquals(childWinTitle, exp[i - 1]);

			HomePage.implicitwait();

			List<WebElement> elements = grid.findElements(By.tagName("li"));
			testlogger().log(Status.INFO, "Total products:" + elements.size());
			System.out.println("Total products:" + elements.size());

			for (int j = 1; j <= 3; j++) {
				boolean AddtoCartBtn = false, PreOrderBtn = false, NewLabel = false, BestsellerLabel = false,
						Productprice = false, AddToCart = false, PreOrder = false;

				try {
					ProductName = driver.findElement(By
							.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j + "]/div/div[2]/strong/a"));
				} catch (Exception e) {
					// TODO: handle exception
				}

				try {

					AddtoCartBtn = driver.findElement(By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j
							+ "]/div/div[2]/div[3]/div/div[1]/form/button/span")).isDisplayed();

					PreOrderBtn = driver.findElement(By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j
							+ "]/div/div[2]/div[3]/div/div[1]/form/button/span")).isDisplayed();
				} catch (Exception e) {
					// TODO: handle exception
				}

				try {
					NewLabel = driver
							.findElement(
									By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j + "]/div/span"))
							.isDisplayed();

					BestsellerLabel = driver
							.findElement(By
									.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j + "]/div/span[2]"))
							.isDisplayed();

				} catch (Exception e) {

				}

				try {
					ProductPrice = driver.findElement(By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j
							+ "]/div/div[2]/div[1]/span[1]/span/span[2]/span"));
					Productprice = ProductPrice.isDisplayed();

				} catch (Exception e) {
					// TODO: handle exception
				}

				try {
					AddtoCart = driver.findElement(By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j
							+ "]/div/div[2]/div[1]/span[1]/span/span[2]/span"));
					AddToCart = AddtoCart.isDisplayed();
				} catch (Exception e) {
					// TODO: handle exception
				}
				try {
					AddtoCart = driver.findElement(By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j
							+ "]/div/div[2]/div[3]/div/div[1]/form/button/span"));
					AddToCart = AddtoCart.isDisplayed();
				} catch (Exception e) {
					// TODO: handle exception
				}
				try {
					Preorder = driver.findElement(By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j
							+ "]/div/div[2]/div[4]/div/div[1]/form/button"));
					PreOrder = Preorder.isDisplayed();
				} catch (Exception e) {
					// TODO: handle exception
				}

				System.out
						.println(j + " ProductName - " + ProductName.getText() + "\n" + " Add to cart button present - "
								+ AddtoCartBtn + "\n" + " Pre Order button present - " + PreOrderBtn + "\n"
								+ " New Label is displayed - " + NewLabel + "\n" + " Bestseller Label is displayed - "
								+ BestsellerLabel + "\n" + " Product price is displayed -" + Productprice + "\n"
								+ " Product price = " + ProductPrice.getAttribute("innerHTML").replace("[^0-9.]", "")
								+ "\n" + "AddtoCart button is displayed:" + AddToCart + "\n"
								+ "Pre-order button is displayed:" + PreOrder);
				testlogger().log(Status.INFO,
						j + " ProductName - " + ProductName.getText() + " <br />" + " Add to cart button present - "
								+ AddtoCartBtn + " <br />" + " Pre Order button present - " + PreOrderBtn + " <br />"
								+ " New Label is displayed - " + NewLabel + " <br />"
								+ " Bestseller Label is displayed - " + BestsellerLabel + " <br />"
								+ " Product price is displayed -" + Productprice + "\n" + " Product price = "
								+ ProductPrice.getAttribute("innerHTML").replace("[^0-9.]", "") + " <br />"
								+ "AddtoCart button is displayed:" + AddToCart + " <br />"
								+ "Pre-order button is displayed:" + PreOrder);

				if (ProductPrice.getAttribute("innerHTML").replace("[^0-9.]", "").contentEquals("0.00")) {
					System.out.println("Fatal Error");
					testlogger().log(Status.FATAL, "Price cannot be zero");
				}

			}

			/*
			 * driver.close(); testlogger().log(Status.INFO, "Child window closed.");
			 * System.out.println("Child window closed."); } }
			 */
			driver.navigate().back();
			testlogger().log(Status.INFO, "Navigated to parent Window.");
			System.out.println("Navigated to parent Window.");
			driver.navigate().refresh();
			HomePage.implicitwait();

		}
	}

}
