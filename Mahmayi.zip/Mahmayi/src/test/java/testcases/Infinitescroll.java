package testcases;

import org.testng.annotations.Test;

import base.TestBase;
import pages.Scroll;

public class Infinitescroll extends TestBase{
	static Scroll scroll;

	public Infinitescroll() {
		super();
	}
	
	@SuppressWarnings("static-access")
	@Test(priority = 0,enabled = false)
	public static void TC() {
		scroll.test();
	}
	
	@SuppressWarnings("static-access")
	@Test(priority = 0,enabled = true)
	public static void TC2() {
		scroll.test2();
		}
}
