package testcases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.TestBase;
import pages.LoginPage;
import pages.LogoutPage;
import pages.MyCartPage;

public class MyCartPageTest extends TestBase {

	static MyCartPage myCartPage;
	static LoginPage loginpage;

	public MyCartPageTest() {
		super();
	}

	@BeforeTest
	public void setup() throws Exception {
		TestBase.initialization(); // calling initilization method
		loginpage = new LoginPage(driver);
		LoginPage.login(property.getProperty("email"), property.getProperty("password"));
		Thread.sleep(5000);
		
	}

	@SuppressWarnings("static-access")
	@Test(priority = 0, enabled = true)
	public static void AddToCartTest() {
		myCartPage.pdp();
		myCartPage.clickAddToCartBtn();
		myCartPage.getmessage();
		//check if product added to minicart
		myCartPage.clickToOpenCart();
		myCartPage.ListInMiniCart();
		myCartPage.checkMiniCart();
		//check if product added to cart
		myCartPage.OpenCart();
		myCartPage.ListInCart();
		myCartPage.checkCart();
		

	}

	@SuppressWarnings("static-access")
	@Test(priority = 1, enabled = true)
	public static void deleteFromCartTest() {
		myCartPage.OpenCart();
		myCartPage.deleteitem();
		myCartPage.getmessage();
		myCartPage.clickToOpenCart();
		myCartPage.deletecheckMiniCart();

	}

	@SuppressWarnings("static-access")
	@Test(priority = 2, enabled = false)
	public static void CartPriceTest() {
		myCartPage.OpenCart();
		myCartPage.cartSubtotal();
		myCartPage.cartOrderTotal();
		myCartPage.cartItemsCount();
	}

	@SuppressWarnings("static-access")
	@Test(priority = 3, enabled = false)
	public static void MiniCartTest() throws InterruptedException {
		 myCartPage.clickToOpenCart();
		 myCartPage.CounterNo();
		
	}
	@SuppressWarnings("static-access")
	@Test(priority = 4, enabled = false)
	public static void Cart_outofstock_Test() throws InterruptedException {
		 myCartPage.OpenCart();
		 myCartPage.name();
		
	}
	
	@SuppressWarnings("static-access")
	@Test(priority = 3,enabled = false)
	public static void totalQtyMiniCart() {
		myCartPage.totalSum();
	}

	@AfterTest
	public static void teardown() {
		LogoutPage.logout();
		driver.close();
	}
}
