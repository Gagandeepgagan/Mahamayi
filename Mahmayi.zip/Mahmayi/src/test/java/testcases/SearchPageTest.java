package testcases;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.TestBase;
import pages.LoginPage;
import pages.LogoutPage;
import pages.Searchpage;

public class SearchPageTest extends TestBase {
	static Searchpage searchpage;
	static LoginPage loginpage;

	public SearchPageTest() {
		super();
	}

	@BeforeTest
	public void setup() throws Exception {
		TestBase.initialization(); // calling initilization method
		loginpage = new LoginPage(driver);
		LoginPage.login(property.getProperty("email"), property.getProperty("password"));
		Thread.sleep(5000);
		
	}

	@SuppressWarnings("static-access")
	@Test(priority = 0, enabled = true)
	public static void Testcase1() {
		searchpage.openhomepage();
		searchpage.clickonSerachbox();
		searchpage.search();
	}
	
	@AfterTest
	public static void teardown() {
		LogoutPage.logout();
		driver.close();
	}
}
