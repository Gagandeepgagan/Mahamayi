package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

import base.TestBase;

public class HomePage<logger> extends TestBase {
	static HomePage<?> homePage;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public static void implicitwait() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public static void jsclick(WebElement element) {
		new WebDriverWait(driver, 60).ignoring(ElementNotInteractableException.class)
				.until(ExpectedConditions.elementToBeClickable(element));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}

	public static void NoSuchElement(WebElement element) {
		new WebDriverWait(driver, 10).ignoring(NullPointerException.class,NoSuchElementException.class)
				.until(ExpectedConditions.visibilityOf(element));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public static void ElementNotInteractable(WebElement element) {
		new WebDriverWait(driver, 30).ignoring(ElementNotInteractableException.class)
				.until(ExpectedConditions.elementToBeClickable(element));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}
	
	public static void ElementClickIntercepted(WebElement element) {
		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
		.until(ExpectedConditions.elementToBeClickable(element));
((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}

	public static void scroll() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}
	
	public static String getInnerHTML(WebElement element) {
		String actual = element.getAttribute("innerHTML").trim();
		testlogger().log(Status.INFO,  actual);
		System.out.println( actual);
		return actual;
	}

	public static String getTitle() {
		String expected = driver.getTitle();
		testlogger().log(Status.INFO, "Title: " + expected);
		System.out.println("Title: " + expected);
		return expected;
}
}