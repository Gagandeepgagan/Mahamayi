package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import base.TestBase;

public class Wishlist extends TestBase {
	static Wishlist wishlist = new Wishlist();

	public Wishlist() {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[1]/div/div[2]/strong/a")
	static WebElement ProductName;

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[1]/div/div[2]/div[3]/div/div[2]/a[1]/span")
	protected static WebElement WishlistIcon;

	@FindBy(xpath = "//*[@id='wishlist-view-form']/div[1]/ol")
	static WebElement listinWishlist;

	@FindBy(xpath = "//*[@id='maincontent']/div[1]/div[2]/div/div/div/text()")
	static WebElement msg;

	@FindBy(xpath = "//*[@class='products-grid wishlist']/ol/li/div/div[2]/div[3]/a[2]/span")
	static WebElement delete;

	@FindBy(xpath = "//*[@id='item_1081']/div/div[2]/div[2]/fieldset/div[1]/div")
	static WebElement qty;

	@FindBy(xpath = "//*[@id='wishlist-view-form']/div[2]/div[1]/button[3]/span")
	static WebElement AddAlltocart;

	@FindBy(xpath = "//*[@class='products-grid wishlist']/ol/li/div/strong/a")
	static WebElement productname;
	static String Expected, Actualoutput, successmsg;

	public static void openPage() {
		driver.get(property.getProperty("url") + "/office-furniture.html");
		HomePage.implicitwait();
	}

	public static void OpenWishlist() {
		driver.get(property.getProperty("url") + "wishlist");
		HomePage.implicitwait();
	}

	public static void clickonwishlist() {
		driver.get(property.getProperty("url") + "office-furniture.html");
		HomePage.implicitwait();
		Expected = ProductName.getAttribute("innerHTML").trim();
		HomePage.ElementClickIntercepted(WishlistIcon);
		HomePage.implicitwait();
		Wishlist.getSuccessMsg();
	}

	public static void getSuccessMsg() {
		successmsg = msg.getText().trim();
		testlogger().log(Status.INFO, successmsg);
		System.out.println(successmsg);
	}

	public static void additem() {

		clickonwishlist();

		HomePage.NoSuchElement(listinWishlist);

		List<WebElement> products = listinWishlist.findElements(By.tagName("li"));
		testlogger().log(Status.INFO, "Products in Wishlist" + products.size());
		System.out.println("Products in Wishlist: " + products.size());

		for (int i = 1; i <= products.size(); i++) {

			productname = driver
					.findElement(By.xpath("//*[@id='wishlist-view-form']/div[1]/ol/li[" + i + "]/div/strong/a"));
			Actualoutput = productname.getAttribute("innerHTML").trim();
			testlogger().log(Status.INFO, i + "-" + Actualoutput);
			System.out.println(i + "-" + Actualoutput);

			if (Actualoutput.equals(Expected)) {
				testlogger().log(Status.INFO, "Product added to Wishlist");
				System.out.println("Product added to Wishlist");
			} else {
				testlogger().log(Status.INFO, "Product not added to wishlist");
				System.out.println("Product not added to wishlist");
			}

		}
	}

	public static void hover() {
		String javaScript = "var evObj = document.createEvent('MouseEvents');"
				+ "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
				+ "arguments[0].dispatchEvent(evObj);";

		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";

		((JavascriptExecutor) driver).executeScript(javaScript, productname);
		((JavascriptExecutor) driver).executeScript(mouseOverScript, productname);
		
		((JavascriptExecutor) driver).executeScript(javaScript, delete);
		((JavascriptExecutor) driver).executeScript(mouseOverScript, delete);
		
		 ((JavascriptExecutor)driver).executeScript("arguments[0].click();",delete);
		
		

		/*
		 * Actions action = new Actions(driver);
		 * action.moveToElement(productname).build().perform();
		 */

		/*
		 * https://stackoverflow.com/questions/17293914/how-to-perform-mouseover-
		 * function-in-selenium-webdriver-using-java
		 */
	}

	public static void Deleteitem() {

		OpenWishlist();
		/*
		 * HomePage.NoSuchElement(listinWishlist); List<WebElement> productsmini =
		 * listinWishlist.findElements(By.tagName("li")); int before =
		 * productsmini.size();
		 */

		Wishlist.hover();

		//HomePage.ElementClickIntercepted(delete);

		Wishlist.getSuccessMsg();

		if (successmsg.equalsIgnoreCase("been removed from your Wish List.")) {
			testlogger().log(Status.INFO, "Product has been removed from your Wish List");
			System.out.println("Product has been removed from your Wish List");
		}

		else {
			testlogger().log(Status.INFO, "Product has not been removed from your Wish List");
			System.out.println("Product has not been removed from your Wish List");
		}
		/*
		 * int after = productsmini.size(); int result = before - after; if (result ==
		 * 1) { testlogger().log(Status.INFO,
		 * "Size of list decreased on deleting product");
		 * System.out.println("Size of list decreased on deleting product"); }
		 */
	}

	public static void updateqty() {
		Wishlist.clickonwishlist();
		Wishlist.hover();
		int Quantity1 = Integer.parseInt(qty.getAttribute("value"));
		System.out.println(Quantity1);
		Wishlist.clickonwishlist();
		Wishlist.hover();
		int Quantity2 = Integer.parseInt(qty.getAttribute("value"));
		System.out.println(Quantity2);
		if (Quantity2 > Quantity1) {
			System.out.println("Qunatity is updated ");
		} else {
			System.out.println("Qunatity is not updated ");
		}

	}

	public static void Movetocart() {
		List<WebElement> products = listinWishlist.findElements(By.tagName("li"));
		System.out.println(products.size());
		HomePage.NoSuchElement(AddAlltocart);
		AddAlltocart.click();
		System.out.println("Clicked on AddAlltocart button ");
		HomePage.implicitwait();
		Wishlist.getSuccessMsg();

		System.out.println(
				driver.findElement(By.xpath("//*[@id='wishlist-view-form']/div[1]/span/text()")).getText().trim());
	}
}
