package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import base.TestBase;

public class NewsletterPage extends TestBase {
	static NewsletterPage newsletterPage = new NewsletterPage();


	@FindBy(id = "newsletter")
	static WebElement emailNL;

	@FindBy(xpath = "//*[@id=newsletter-validate-detail]/div[2]/button/span")
	static WebElement SubmitNL;

	@FindBy(xpath = "//*[@id='maincontent']/div[1]/div[2]/div/div/div")
	static WebElement message;

	@FindBy(xpath = "//div[@id='newsletter-error']")
	static WebElement errormessage;

	public NewsletterPage() {
		PageFactory.initElements(driver, this);
	}

	public static WebElement ValidEmail(String newsletterEmail) {
		HomePage.implicitwait();
	
		HomePage.scroll();
		testlogger().log(Status.INFO, "Scrolled to bottom of page.");
		HomePage.implicitwait();
		HomePage.NoSuchElement(emailNL);
		emailNL.clear();
		emailNL.sendKeys(newsletterEmail + Keys.ENTER);
		testlogger().log(Status.INFO, "Entered email= " + newsletterEmail);
		testlogger().log(Status.INFO, "Clicked on submit button");
		HomePage.implicitwait();
		HomePage.NoSuchElement(message);
		if (message.isDisplayed()) {
			testlogger().log(Status.PASS, "Email registered for NewsLetter " + "Thank you for your subscription.");
		} else {
			testlogger().log(Status.INFO, "Something went wrong with the subscription.");
		}
		return message;
	}

	public static void BlankEmail() {
		HomePage.implicitwait();
		HomePage.scroll();
		testlogger().log(Status.INFO, "Scrolled to bottom of page.");
		HomePage.implicitwait();
		HomePage.NoSuchElement(emailNL);
		emailNL.clear();
		emailNL.sendKeys(Keys.ENTER);
		testlogger().log(Status.INFO, "Clicked on submit button");
		HomePage.implicitwait();
		HomePage.NoSuchElement(errormessage);
		Assert.assertEquals(errormessage.getAttribute("innerHTML"), "This is a required field.");
		testlogger().log(Status.PASS, "Email address for NewsLetter is empty.");
	}

	public static void RegisteredEmail(String newsletterEmail) {
		HomePage.implicitwait();
		HomePage.scroll();
		testlogger().log(Status.INFO, "Scrolled to bottom of page.");
		HomePage.implicitwait();
		HomePage.NoSuchElement(emailNL);
		emailNL.clear();
		emailNL.sendKeys(newsletterEmail + Keys.ENTER);
		testlogger().log(Status.INFO, "Entered email= " + newsletterEmail);
		testlogger().log(Status.INFO, "Clicked on submit button");
		HomePage.implicitwait();
		HomePage.NoSuchElement(message);
		Assert.assertEquals(message.getAttribute("innerHTML"), "This email address is already subscribed.");
		testlogger().log(Status.PASS, "Email already registered for NewsLetter ");
		
	}

	public static WebElement InValidEmail(String newsletterEmail) {
		HomePage.implicitwait();
		HomePage.scroll();
		testlogger().log(Status.INFO, "Scrolled to bottom of page.");
		HomePage.implicitwait();
		HomePage.NoSuchElement(emailNL);
		emailNL.clear();
		emailNL.sendKeys(newsletterEmail + Keys.ENTER);
		testlogger().log(Status.INFO, "Entered email= " + newsletterEmail);
		testlogger().log(Status.INFO, "Clicked on submit button");
		HomePage.implicitwait();
		HomePage.NoSuchElement(errormessage);
		if (errormessage.getAttribute("innerHTML")
				.equalsIgnoreCase("Please enter a valid email address (Ex: johndoe@domain.com).")) {
			testlogger().log(Status.PASS, "Email registered for NewsLetter is invalid");
		} else if (errormessage.getAttribute("innerHTML").equalsIgnoreCase("Something went wrong with the subscription.")) {
			testlogger().log(Status.PASS, "Something went wrong with the subscription.");
		}
		return errormessage;
	}

}
