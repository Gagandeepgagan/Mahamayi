package utilities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.TestBase;

public class TestUtil extends TestBase {

	static WebDriverWait wait;

	public static void jsclick(WebElement elemt) {
		new WebDriverWait(driver, 60).ignoring(ElementNotInteractableException.class)
				.until(ExpectedConditions.elementToBeClickable(elemt));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", elemt);
	}

	public static void NoSuchElement(WebElement element) {
		new WebDriverWait(driver, 60).ignoring(NoSuchElementException.class)
				.until(ExpectedConditions.elementToBeClickable(element));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public static void ElementNotInteractable(WebElement element) {
		new WebDriverWait(driver, 30).ignoring(ElementNotInteractableException.class)
				.until(ExpectedConditions.elementToBeClickable(element));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public static void ElementClickIntercepted(WebElement element) {
		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(element));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
	}

	public static void scroll() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}

	// Check the visibility of the element and then perform click
	public static void clickElement(WebElement save) {
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(save));
		
		save.click();

	}

	// Check the visibility of the element and then enter the value in text field
	public static void enterInTextField(By locator, String value) {
		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));

		new WebDriverWait(driver, 30).ignoring(ElementClickInterceptedException.class)
				.until(ExpectedConditions.elementToBeClickable(locator));
		((JavascriptExecutor) driver).executeScript("arguments[0].click();", locator);

		WebElement element = driver.findElement(locator);
		element.clear();
		element.sendKeys(value);

	}

	// Check the visibility of the element and then get the text
	public static String getTextOfElement(WebElement name) {

		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated((By) name));

		new WebDriverWait(driver, 60).ignoring(NoSuchElementException.class)
				.until(ExpectedConditions.elementToBeClickable(name));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", name);

		String text = name.getText();
		return text.trim();

	}

	public static void scrollToElement(List<WebElement> products) {
		System.out.println("scroll to element");
		
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", products);
		// Thread.sleep(500);
	}

	public static boolean elementIsDisplayed(WebElement locator) {
		boolean visible = driver.findElement((By) locator).isDisplayed();
		return visible;
	}

	public static void clickByJs(WebElement locator) {
		System.out.println("Clicking on the element");
		
		new WebDriverWait(driver, 30).ignoring(ElementNotInteractableException.class)
				.until(ExpectedConditions.elementToBeClickable(locator));
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", locator);

	}

	public List<WebElement> list(WebElement locator) {
		List<WebElement> list = driver.findElements((By) locator);
		return list;
	}
}
