package listeners;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import base.TestBase;
import utilities.ExtentManager;

public class MyListener extends TestBase implements ITestListener, ISuiteListener {

	static ExtentReports extent;
	

	public void onStart(ISuite suite) {
		System.out.println("on test start: ");
	}

	public void onTestSuccess(ITestResult result) {
		System.out.println(" test passed");
		String passLog = "Test passed";
		Markup mp = MarkupHelper.createLabel(passLog, ExtentColor.GREEN);
		testlogger().log(Status.PASS, mp);

		ExtentManager.getExtent().flush();
		// extent.flush();
	}

	public void onTestFailure(ITestResult result) {
		System.out.println(" test failed");
		String screenShotPath = "./Screenshots";
		try {
			screenShotPath = capture(driver, result.getName() );
		} catch (IOException e2) {
			// e2.printStackTrace();
		}
		testlogger().log(Status.FAIL, MarkupHelper.createLabel(
				"Method:" + result.getName() + "    Test case FAILED due to below issues:", ExtentColor.RED));
		testlogger().fail(result.getThrowable());
		try {
			
			String screenShotName = null;
			testlogger().fail("Snapshot placed in :  " + screenShotPath+testlogger().addScreenCaptureFromPath(capture(driver, screenShotName)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		ExtentManager.getExtent().flush();
		// extent.flush();
	}

	public static String capture(WebDriver driver, String screenShotName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String dest = System.getProperty("user.dir") + "./Screenshots/" + screenShotName + ".png";
		File destination = new File(dest);
		FileUtils.copyFile(source, destination);
		return dest;

	}
 
	public void onTestSkipped(ITestResult result) {
		System.out.println(" test skip");
		String passLog = "Test skip";
		Markup mp = MarkupHelper.createLabel(passLog, ExtentColor.ORANGE);
		testlogger().log(Status.SKIP, mp);

		ExtentManager.getExtent().flush();

		testlogger().skip(" test is skipped");
		System.out.println("on test skipped");
		extent.flush();
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	public void onTestStart(ITestResult result) {
		System.out.println("on start");
		
		  ExtentTest child = classLevelLogger.get().createNode(result.getName());
		  testLevelLogger.set(child);
		 
	}

	public void onFinish(ISuite suite) {
		System.out.println("on finish");
	}

	public void onFinish(ITestContext context) {

	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub

	}

}