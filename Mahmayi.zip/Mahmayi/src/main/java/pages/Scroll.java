package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.Status;

import base.TestBase;

public class Scroll extends TestBase {
	static Scroll scroll = new Scroll();

	public Scroll() {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[4]/ol")
	static WebElement list;

	static String[] pagess;
	static JavascriptExecutor jse = (JavascriptExecutor) driver;
	static ArrayList<String> ProductName2;

	public static void test() {
		driver.get(property.getProperty("url") + "safes.html");
		HomePage.implicitwait();

		jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		ArrayList<String> ProductName = new ArrayList<String>();

		while (pagess[1] != pagess[3]) {
			jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		}

		List<WebElement> listL = list.findElements(By.tagName("li"));
		int listsize = listL.size();

		System.out.println("Products :" + listsize);

		for (int i = 1; i <= listsize; i++) {

			WebElement Name = driver.findElement(
					By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + i + "]/div/div[2]/strong/a"));
			String output = Name.getAttribute("innerHTML").trim();

			ProductName.add(output);
		}
		System.out.println(ProductName);

	}

	public static boolean isloaderPresent() {

		WebElement footer = driver.findElement(By.xpath("/html/body/div[3]/small"));
		boolean footerpresent = footer.isDisplayed();
		return footerpresent;
	}

	public static void page() {
		WebElement pageno = driver.findElement(By.xpath("//*[@id='amscroll-navbar']/span"));
		String pages = pageno.getText();
		pagess = pages.trim().split("\\s+");

		System.out.println("onpage ::" + pagess[1]);
		System.out.println("totalpage ::" + pagess[3]);
	}

	@SuppressWarnings("unchecked")
	public static void test2() {
		// TODO Auto-generated method stub
		driver.get(property.getProperty("url") + "safes.html");
		HomePage.implicitwait();

		jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");

		List<WebElement> List = list.findElements(By.tagName("li"));
		ProductName2 = new ArrayList<String>();
		int i = 0;
		int numberOfAvailableProducts;
		while (true) {

			numberOfAvailableProducts = List.size();
			System.out.println("numberOfAvailableProductsOnScroll-" + numberOfAvailableProducts
					+ "  No_of_total_products_in_List-" + ProductName2.size());

			testlogger().log(Status.INFO, "numberOfAvailableProductsOnScroll-" + numberOfAvailableProducts
					+ "  No_of_total_products_in_List-" + ProductName2.size());

			try {
				jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");

			} catch (Exception e) {

			}
			i++;
			System.out.println("Page - " + i);
			testlogger().log(Status.INFO, "Page - " + String.valueOf(i));
			for (int j = ProductName2.size() + 1; j <= ProductName2.size() + 12; j++) {

				try {
					WebElement product2 = driver.findElement(
							By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[" + j + "]/div/div[2]/strong/a"));
					String outputt = product2.getAttribute("innerHTML").trim();
					System.out.println(j + " - " + outputt);
					testlogger().log(Status.INFO, j + " - " + outputt);
					ProductName2.add(outputt);
				
				} catch (Exception e) {
					// TODO: handle exception
				}
			
			}
			System.out.println(ProductName2);
			if (i == 7) {
				System.out.println("Breaking...");
				break;
			
			
		}
		}
	}
}