package testcases;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBase;
import pages.NewsletterPage;

public class NewsletterPageTest extends TestBase {
	static NewsletterPage newsletterPage;
	static String email=RandomStringUtils.randomAlphabetic(5)+property.getProperty("NLemail");
	public NewsletterPageTest() {
		super();
	}

	@BeforeClass
	public void setup() throws Exception {
		TestBase.initialization();
	
	}

	@SuppressWarnings("static-access")
	@Test(priority = 0, enabled = true)
	public static void NewsLetterValidEmail() {
		
		newsletterPage.ValidEmail(email);
	}

	@SuppressWarnings("static-access")
	@Test(priority = 1, enabled = true)
	public void NewsLetterInValidEmail() {
		newsletterPage.InValidEmail(property.getProperty("NLemailinvalid"));
	}

	@SuppressWarnings("static-access")
	@Test(priority = 2, enabled = true)
	public void NewsLetter_registeredEmail() {
		newsletterPage.RegisteredEmail(email);
	}

	@SuppressWarnings("static-access")
	@Test(priority = 3, enabled = true)
	public void NewsLetterBlankEmail() {
		newsletterPage.BlankEmail();
	}

	@AfterClass
	public void close() {
		driver.close();
	}
}
