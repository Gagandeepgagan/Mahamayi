package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBase;
import pages.HomePage;
import pages.LoginPage;
import pages.LogoutPage;


public class LogoutPageTest extends TestBase {

	static LoginPage loginpage;
	static HomePage<?> homePage;
	static LogoutPage logoutPage;

	public LogoutPageTest() {
		super();
	}

	@BeforeClass
	public void setup() throws Exception {
		TestBase.initialization(); 
		loginpage = new LoginPage(driver);
		
	}

	
	@Test(priority = 0)
	public static void Login() throws Exception {

		LoginPage.login(property.getProperty("email"), property.getProperty("password"));
		
	}
	@Test(priority = 1)
	public void Logout() {
		LogoutPage.logout();
	}

	@AfterClass
	public void close() {
		driver.close();
	}
}
