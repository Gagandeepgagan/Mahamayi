package base;

import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import utilities.ExtentManager;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;



public class TestBase {
	
	public static WebDriver driver=null;
	public static Properties property;
	protected static ExtentReports extent;
	 
	
	protected static ThreadLocal<ExtentTest> classLevelLogger = new ThreadLocal<ExtentTest>();
	protected static  ThreadLocal<ExtentTest> testLevelLogger = new ThreadLocal<ExtentTest>();

		
		public TestBase() {
		

		try {
			property = new Properties();
			FileInputStream fis = new FileInputStream(
					System.getProperty("user.dir") + "/src/main/java/config/config.properties");
			property.load(fis);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@BeforeSuite
	public static void initialization() throws Exception {

		String browserName = property.getProperty("browser");

		if (browserName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe ");
			driver = new ChromeDriver();

		} else if (browserName.equals("firefox")) {
			System.setProperty("webdriver.gecko.driver", "./Driver/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		driver.manage().deleteAllCookies();
		
		driver.get(property.getProperty("url"));
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		extent = ExtentManager.getExtent();
	}

	@BeforeClass
	public void before_class() {
		ExtentTest	 parent = extent.createTest(getClass().getName());
		classLevelLogger.set(parent);
	}

	@BeforeMethod
	private void before_method(Method method) {
		System.out.println("Execution of method: " + method.getName() + "started");
	}

	@AfterSuite
	public void as() {
	
		 extent.flush();
		driver.quit();
	}

	
	
	public static ExtentTest testlogger() {
		return testLevelLogger.get();
	}
}



