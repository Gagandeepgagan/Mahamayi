package pages;

import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.aventstack.extentreports.Status;

import base.TestBase;

public class LogoutPage extends TestBase {
	
	static LogoutPage logoutPage=new LogoutPage();
	
	/*
	 * @FindBy(xpath = "//ul[@class='header links']/li[2]/span") static WebElement
	 * profile;
	 * 
	 * @FindBy(xpath = "//ul[@class='account links']/li[2]/a") static WebElement
	 * logout;
	 */

	public LogoutPage()
    {
		PageFactory.initElements(driver, this);
	}

	public static void logout() {
		
		driver.get("https://mahmayim2.pub.vtnetzwelt.com/customer/account/logoutSuccess/");
		//Assert.assertEquals(driver.getCurrentUrl(), "https://mahmayim2.pub.vtnetzwelt.com/customer/account/logoutSuccess/");
		//testlogger().log(Status.PASS, "User Logged out successfully.");
		System.out.println("User Logged out successfully.");
	}

}
