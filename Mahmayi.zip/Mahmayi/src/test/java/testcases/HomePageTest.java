package testcases;

import org.testng.annotations.BeforeClass;
import base.TestBase;
import pages.HomePage;

public class HomePageTest extends TestBase {
	
	static HomePage<?> homePage= new HomePage<Object>(driver);

	public HomePageTest() {
		super();
	}

	@BeforeClass
	public void setUp() throws Exception {
		TestBase.initialization();
		
	}

	
	
}
