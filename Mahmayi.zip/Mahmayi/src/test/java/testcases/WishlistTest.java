package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBase;
import pages.LoginPage;
import pages.LogoutPage;
import pages.WishlistPage;

public class WishlistTest  extends TestBase{
	static WishlistPage wishlistPage;
	static LoginPage loginpage;

	public WishlistTest() {
		super();
	}

	@BeforeClass
	public  void setup() throws Exception {
		TestBase.initialization(); // calling initilization method
		loginpage = new LoginPage(driver);
		LoginPage.login(property.getProperty("email"), property.getProperty("password"));
		Thread.sleep(5000);
	}

	
	
	
	
	@SuppressWarnings("static-access")
	@Test(priority = 0,enabled = false)
	public static void Additem() {
		wishlistPage.additem();
	}

	@SuppressWarnings("static-access")
	@Test(priority = 2, enabled = true)
	public static void Deleteitem() {
		wishlistPage.Deleteitem();
	}
	
	@SuppressWarnings("static-access")
	@Test(priority = 1, enabled = false)
	public static void UpdateQtyofitem() {
		wishlistPage.updateqty();
	}
	
	@SuppressWarnings("static-access")
	@Test(priority = 4,enabled = false)
	public static void MoveitemtoCart() {
		wishlistPage.Movetocart();
	}
	
	@SuppressWarnings("static-access")
	@Test(priority = 3,enabled = false)
	public static void ShareWishlist() {
		wishlistPage.sharewishlist();
	}
	
	

	@AfterClass
	public static void teardown() {
		LogoutPage.logout();
	}
}


