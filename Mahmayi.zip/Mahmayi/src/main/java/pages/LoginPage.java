package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.aventstack.extentreports.Status;

import base.TestBase;

public class LoginPage extends TestBase {
	static WebDriver driver;
	static LoginPage loginPage;
	static HomePage<?> homePage;
	// page objects

	@FindBy(xpath = "/html/body/div[3]/header/div[2]/ul/li[4]/a")
	static WebElement Signin;

	/*
	 * @FindBy(id = "email") public static WebElement email;
	 * 
	 * @FindBy(id = "pass") static WebElement password;
	 * 
	 * @FindBy(id = "send2") static WebElement signinbtn;
	 */
	@FindBy(id = "social_login_email")
	public static WebElement email;

	@FindBy(id = "social_login_pass")
	static WebElement password;

	@FindBy(id = "bnt-social-login-authentication")
	static WebElement signinbtn;

	@FindBy(xpath = "//*[@id='maincontent']/div[2]/div[1]/div[3]/div[2]/div/div[1]/p/text()[2]")
	static WebElement MA_email;

	@FindBy(xpath = "//div[@class='messages']/div/div")
	static WebElement errorMessage;

	@FindBy(xpath = "")
	static WebElement successMessage;

	@FindBy(xpath = "//*[@id='social-login-popup']/button")
	static WebElement closepopup;

	public LoginPage(WebDriver dr) {
		this.driver = dr;
		PageFactory.initElements(driver, this);
	}

	public static void login(String un, String pwd) throws Exception {
		// testlogger().log(Status.INFO, "Browser launched and navigated to Mahmayi");
		System.out.println("Browser launched and navigated to Mahmayi");
		HomePage.implicitwait();
		HomePage.ElementClickIntercepted(Signin);
		Thread.sleep(2000);
		driver.switchTo().activeElement();
		HomePage.ElementNotInteractable(email);
		email.sendKeys(un);
		// testlogger().log(Status.INFO, "Email: " + un);
		System.out.println("Email: " + un);
		HomePage.ElementNotInteractable(password);
		password.sendKeys(pwd);
		// testlogger().log(Status.INFO, "Password: " + pwd);
		System.out.println("Password: " + pwd);
		HomePage.ElementClickIntercepted(signinbtn);
		//testlogger().log(Status.INFO, "Clicked on Sign in button. ");
		System.out.println("Clicked on Sign in button. ");
		Thread.sleep(20000);

		if (driver.getTitle().contentEquals("My Account")) {
			System.out.println("User Logged in.");
			// testlogger().pass("Login successful with valid email and valid password");
		} else { // testlogger().pass("Login Failed");
		}

	}

	public HomePage<?> Blank() throws Exception {

		driver.get(property.getProperty("url"));
		HomePage.implicitwait();
		/*
		 * if (closepopup.isDisplayed()) { closepopup.click();
		 * System.out.println("notification popup closed"); }
		 */
		HomePage.NoSuchElement(Signin);
		Signin.click();
		Thread.sleep(2000);
		HomePage.NoSuchElement(signinbtn);
		signinbtn.click();
		Thread.sleep(2000);
		return new HomePage(driver);
	}

	public WebElement checkUser(WebDriver driver) {

		HomePage.NoSuchElement(MA_email);

		MA_email.isDisplayed();
		testlogger().log(Status.INFO, "Email Logged in User: " + MA_email.getText().trim());
		System.out.println("Email Logged in User: " + MA_email.getText().trim());
		return MA_email;
	}

	public WebElement getErrorMessage(WebDriver driver) {
		errorMessage.isDisplayed();
		System.out.println(errorMessage.getText());
		return errorMessage;
	}

	public Object getWelcomeMessage(WebDriver driver) {
		successMessage.isDisplayed();
		System.out.println(successMessage.getText());
		return successMessage;
	}

}
