package utilities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.AnalysisStrategy;
import com.aventstack.extentreports.ExtentReporter;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
	private static ExtentReports extent;
	private static ExtentHtmlReporter htmlReporter;
	static DateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy h-m-s");
    static Date date = new Date();
	private static String filepath = System.getProperty("user.dir")+ "./Extent_Report/ER_"+ dateFormat.format(date)+".html";

	public static ExtentReports getExtent() {

		if (extent != null) {
			return extent;
		} else {
			extent = new ExtentReports();
			extent.attachReporter(getHtmlReporter());
			extent.setSystemInfo("User Name", "netzwelt");
			extent.setSystemInfo("OS", "Windows 8.1");
			extent.setSystemInfo("JavaVersion", "1.8.0_05");
			extent.setAnalysisStrategy(AnalysisStrategy.SUITE);
			return extent;
		}
	}

	private static ExtentReporter getHtmlReporter() {
		htmlReporter = new ExtentHtmlReporter(filepath);
	//	htmlReporter.setAppendExisting(false);
		htmlReporter.loadConfig(System.getProperty("user.dir") + "./src/main/java/config/ReportConfig.xml");
		htmlReporter.config().setTheme(Theme.STANDARD);
		htmlReporter.config().setDocumentTitle("Automation Report");
		htmlReporter.config().getDocumentTitle();
		htmlReporter.config().setReportName("Mahmayi");
		htmlReporter.config().getReportName();
		return htmlReporter;
	}

}

