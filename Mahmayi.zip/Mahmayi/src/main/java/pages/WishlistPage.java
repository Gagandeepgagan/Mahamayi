package pages;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.aventstack.extentreports.Status;

import base.TestBase;

public class WishlistPage extends TestBase {

	static WishlistPage wishlistPage = new WishlistPage();
	static List<WebElement> products;

	public WishlistPage() {

		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[1]/div/div[2]/strong/a")
	static WebElement ProductName;

	@FindBy(xpath = "//*[@id='maincontent']/div[3]/div[1]/div[4]/ol/li[1]/div/div[2]/div[3]/div/div[2]/a[1]/span")
	protected static WebElement WishlistIcon;

	@FindBy(xpath = "//*[@id='wishlist-view-form']/div[1]/ol")
	static WebElement listinWishlist;

	@FindBy(xpath = "//*[@id='maincontent']/div[1]/div[2]/div/div/div")
	static WebElement msg;

	@FindBy(xpath = "//*[@class='products-grid wishlist']/ol/li/div/div[2]/div[3]/a[2]/span")
	static WebElement delete;

	@FindBy(xpath = "//*[@class='products-grid wishlist']/ol/li[last()]/div/div[2]/div[2]/fieldset/div[1]/div/input")
	static WebElement qty;

	@FindBy(xpath = "//*[@id='wishlist-view-form']/div[2]/div/button[3]")
	static WebElement AddAlltocart;

	@FindBy(xpath = "//*[@class='products-grid wishlist']/ol/li/div/strong/a")
	static WebElement productname;
	static String Expected, Actualoutput, successmsg, javaScript, mouseOverScript;
	static Actions action;

	public static void openPage() {
		driver.get(property.getProperty("url") + "/office-furniture.html");
		HomePage.implicitwait();
	}

	public static void OpenWishlist() {
		driver.get(property.getProperty("url") + "wishlist");
		HomePage.implicitwait();
	}

	public static void clickonwishlist() {
		HomePage.NoSuchElement(ProductName);
		Expected = ProductName.getAttribute("innerHTML").trim();
		HomePage.ElementClickIntercepted(WishlistIcon);
		HomePage.implicitwait();
		WishlistPage.getSuccessMsg();
	}

	public static void getSuccessMsg() {
		successmsg = msg.getText().trim();
		testlogger().log(Status.INFO, successmsg);
		System.out.println(successmsg);

	}

	public static void additem() {
		openPage();
		clickonwishlist();
		OpenWishlist();
		WishlistPage.getSuccessMsg();
		HomePage.NoSuchElement(listinWishlist);

		List<WebElement> products = listinWishlist.findElements(By.tagName("li"));
		testlogger().log(Status.INFO, "Products in Wishlist" + products.size());
		System.out.println("Products in Wishlist: " + products.size());

		for (int i = 1; i <= products.size(); i++) {

			productname = driver
					.findElement(By.xpath("//*[@id='wishlist-view-form']/div[1]/ol/li[" + i + "]/div/strong/a"));
			Actualoutput = productname.getAttribute("innerHTML").trim();
			testlogger().log(Status.INFO, i + "-" + Actualoutput);
			System.out.println(i + "-" + Actualoutput);

			if (Actualoutput.equals(Expected)) {
				testlogger().log(Status.INFO, "Product added to Wishlist");
				System.out.println("Product added to Wishlist");
			} else {
				testlogger().log(Status.INFO, "Product not added to wishlist");
				System.out.println("Product not added to wishlist");
			}

		}
	}

	public static void hover() {
		javaScript = "var evObj = document.createEvent('MouseEvents');"
				+ "evObj.initMouseEvent(\"mouseover\",true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);"
				+ "arguments[0].dispatchEvent(evObj);";

		mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";

		((JavascriptExecutor) driver).executeScript(javaScript, productname);
		((JavascriptExecutor) driver).executeScript(mouseOverScript, productname);

		/*
		 * https://stackoverflow.com/questions/17293914/how-to-perform-mouseover-
		 * function-in-selenium-webdriver-using-java
		 */
	}

	public static void Deleteitem() {

		OpenWishlist();

		HomePage.NoSuchElement(listinWishlist);
		List<WebElement> productsmini = listinWishlist.findElements(By.tagName("li"));
		int before = productsmini.size();
		System.out.println(before);

		hover();
		((JavascriptExecutor) driver).executeScript(javaScript, delete);
		((JavascriptExecutor) driver).executeScript(mouseOverScript, delete);

		((JavascriptExecutor) driver).executeScript("arguments[0].click();", delete);

		successmsg = msg.getText().trim();
		testlogger().log(Status.INFO, successmsg);
		System.out.println(successmsg);

		driver.navigate().refresh();

		int after = productsmini.size();
		System.out.println(after);
		int result = before - after;
		try {
			if (result == 1) {
				testlogger().log(Status.PASS, "Product has been removed from your Wish List");
				System.out.println("Product has been removed from your Wish List");
			}
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	public static void updateqty() {
		openPage();
		clickonwishlist();
		OpenWishlist();
		hover();
		int Quantity1 = Integer.parseInt(qty.getAttribute("value"));
		System.out.println(Quantity1);
		openPage();
		clickonwishlist();
		OpenWishlist();
		hover();
		int Quantity2 = Integer.parseInt(qty.getAttribute("value"));
		System.out.println(Quantity2);
		if (Quantity2 > Quantity1) {
			System.out.println("Qunatity is updated ");
		} else {
			System.out.println("Qunatity is not updated ");
		}

	}

	@FindBy(xpath = "//*[@id='wishlist-view-form']/div[1]/span")
	static WebElement noitemsinwishlist;

	public static void Movetocart() {
		OpenWishlist();

		try {
			noitemsinwishlist.isDisplayed();
			System.out.println(noitemsinwishlist.getText().trim());
			testlogger().log(Status.INFO, noitemsinwishlist.getText().trim());
		} catch (Exception e) {
			// TODO: handle exception
		}

		try {
			products = listinWishlist.findElements(By.tagName("li"));
			System.out.println("Items in Wishlist: " + products.size());
			testlogger().log(Status.INFO, "Items in Wishlist: " + products.size());
			HomePage.ElementClickIntercepted(AddAlltocart);

			System.out.println("Clicked on AddAlltocart button ");
			testlogger().log(Status.INFO, "Clicked on AddAlltocart button ");
			HomePage.implicitwait();
			WishlistPage.getSuccessMsg();

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@FindBy(xpath = "//*[@id='wishlist-view-form']/div[2]/div/button[2]")
	static WebElement sharewishlistBTN;

	@FindBy(id = "email_address")
	static WebElement emailaddress;

	@FindBy(id = "message")
	static WebElement message;

	@FindBy(xpath = "//*[@id=\"form-validate\"]/div/div[1]/button")
	static WebElement shareBTN;

	public static void sharewishlist() {
		OpenWishlist();
		HomePage.ElementClickIntercepted(sharewishlistBTN);

		System.out.println("Clicked on share wishlist button ");
		testlogger().log(Status.INFO, "Clicked on  share wishlist button ");
		HomePage.implicitwait();
		
		HomePage.NoSuchElement(emailaddress);
		emailaddress.sendKeys(property.getProperty("email"));
		System.out.println("Email-"+property.getProperty("email"));
		testlogger().log(Status.INFO, "Email-"+property.getProperty("email"));
		
		HomePage.NoSuchElement(message);
		message.sendKeys(property.getProperty("msg"));
		System.out.println("Message-"+property.getProperty("msg"));
		testlogger().log(Status.INFO,"Message-"+ property.getProperty("msg"));
		
		HomePage.ElementClickIntercepted(shareBTN);
		System.out.println("Clicked on share wishlist button ");
		testlogger().log(Status.INFO, "Clicked on  share wishlist button ");
		HomePage.implicitwait();
		WishlistPage.getSuccessMsg();

	}
	
	
}
