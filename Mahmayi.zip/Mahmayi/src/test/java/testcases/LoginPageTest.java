package testcases;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import base.TestBase;
import pages.HomePage;
import pages.LoginPage;
import pages.LogoutPage;

public class LoginPageTest extends TestBase {
	static LoginPage loginPage;
	static HomePage<?> homePage;

	public LoginPageTest() {
		super(); // call parent class constructor. load property file.
	}

	@BeforeClass
	public void setUp() throws Exception {
		initialization(); // calling initilization method
		loginPage = new LoginPage(driver); // created object of LoginPage class to access its methods and functions
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
	}

	

	@Test(enabled = true)
	public static void ValidLogin() throws Exception {

		LoginPage.login(property.getProperty("email"), property.getProperty("password"));
		testlogger().log(Status.INFO, "Email and password are entered. " + "\n" + "Signin button is clicked.");
		
		 
	}

	@AfterClass
	public void teardown() {
		LogoutPage.logout();
		driver.close();
	}

}
