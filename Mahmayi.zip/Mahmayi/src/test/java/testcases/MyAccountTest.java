package testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBase;
import pages.LoginPage;
import pages.LogoutPage;
import pages.MyAccount;

public class MyAccountTest extends TestBase{
	static LoginPage loginpage;
	static MyAccount myAccount;

	public MyAccountTest() {
		super();
	}

	@BeforeClass
	public static void setup() throws Exception {
		TestBase.initialization(); // calling initilization method
		loginpage = new LoginPage(driver);
		LoginPage.login(property.getProperty("email"), property.getProperty("password"));

	}

	
	@SuppressWarnings("static-access")
	@Test(enabled = true)
	public static void TC1() {
		myAccount.getUsername();
		myAccount.editName();
		myAccount.ChangeName();
		myAccount.ClickonSave();
		myAccount.getSuccessmsgtext();
		myAccount.getUsername();
	}
	
	@SuppressWarnings("static-access")
	@Test(enabled = true)
	public static void TC2() {
		//myAccount.getUsername();
		myAccount.editName();
		myAccount.ChangeEmail();
		myAccount.ClickonSave();
		myAccount.getSuccessmsgtext();
		myAccount.getUsername();
	}
	
	@SuppressWarnings("static-access")
	@Test(enabled = true)
	public static void TC3() {
		//driver.get("https://mahmayim2.pub.vtnetzwelt.com/customer/account/");
		myAccount.editName();
		myAccount.ChangePassword();
		myAccount.ClickonSave();
		//myAccount.getSuccessmsgtext();
	}

	@AfterClass
	public static void teardown() {
		LogoutPage.logout();
	}
}
